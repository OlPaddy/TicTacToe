package com.example.tictactoe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    //The 3, 3 is defining the size of our array
    private Button[][] buttons = new Button[3][3];
    //As soon as the game starts this will make it so the first player which is crosses will always be first
    private boolean player1Turn = true;
    //This will count the rounds done to help keep track of the board and decide if a draw is needed to be done
    private int roundCount;
    //These keep track of the points of the players and displays them
    private int player1Points;
    private int player2Points;
    private TextView textViewPlayer1;
    private TextView textViewPlayer2;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //References the xml
        textViewPlayer1 = findViewById(R.id.text_view_player1);
        textViewPlayer2 = findViewById(R.id.text_view_player2);

        //assigning the buttons by looping them all through a nested for loop
        //i < 3 is to create a max of 3 rounds and i++ increments it with each round
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                //"Button is the first part of the id of each button and I and J is to append each of the columns an example is each time they will tick up so the first one will be "button" + 0 + 0, "button" + 0 + 1
                String buttonID = "button_" + i + j;
                //building the resource ids to pass to find view by id
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                //this allows for easy referencing to our buttons without assigning them all one by one

                buttons[i][j] = findViewById(resID);
                buttons[i][j].setOnClickListener(this);
            }
        }
        //this is to set up the reset button button
        Button buttonReset = findViewById(R.id.button_reset);
        buttonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetGame();
            }
        });
    }
//this is for the playing buttons
    @Override
    public void onClick(View view) {
        //this checks if the empty button that was clicked contains a string and if it isnt the case then it means it was already used before
        if (!((Button) view).getText().toString().equals("")) {
            return;
        }
        //this checks if player 1 turn is true
        if(player1Turn) {
            ((Button) view).setText("X");
        } else {
            //this means its player 2s turn
            ((Button) view).setText("O");
        }
        //this makes it go to the next round
        roundCount++;
        //this is to see who won
        if (checkForWin()) {
            if (player1Turn) {
                player1Wins();
            } else {
                player2Wins();
            }
        } else if (roundCount == 9) {
            draw();
        } else {//this is if no one has one or drawn in 9 turns
            player1Turn = !player1Turn;
        }
    }
    private boolean checkForWin() {
        // 2 dimensional string array
        String[][] field = new String[3][3];
        //this saves the known button presses into this array
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                field[i][j] = buttons [i][j].getText().toString();
            }
        }
        //this one compares the fields next to each other in a row
        for (int i = 0; i < 3; i++) {
            if (field[i][0].equals(field[i][1])
                    && field[i][0].equals(field[i][2])//due to these ampersands both these statements have to be true
                    && !field[i][0].equals("")) {//this bottom one is to make sure that it isnt empty
                return true;
            }
        }
        //this one compares the fields next to each other in a column
        for (int i = 0; i < 3; i++) {
            if (field[0][i].equals(field[1][i])
                    && field[0][i].equals(field[2][i])
                    && !field[0][i].equals("")) {
                return true;
            }
        }
        //this one compares the fields next each other diagonally in a rightward position
        if (field[0][0].equals(field[1][1])
                && field[0][0].equals(field[2][2])
                && !field[0][0].equals("")) {
            return true;
        }
        //this one compares the fields next each other diagonally in a leftward position
        if (field[0][2].equals(field[1][1])
                && field[0][2].equals(field[2][0])
                && !field[0][2].equals("")) {
            return true;
        }

        return false;
    }

    private void player1Wins() {
        player1Points++;
        Toast.makeText(this, "Player 1 Wins!", Toast.LENGTH_SHORT).show();
        updatePointsText();//this will update the players overall points at the top
        resetBoard();
    }

    private void player2Wins() {
        player2Points++;
        Toast.makeText(this, "Player 2 Wins!", Toast.LENGTH_SHORT).show();
        updatePointsText();
        resetBoard();
    }

    private void draw() {
        Toast.makeText(this, "Draw!", Toast.LENGTH_SHORT).show();
        resetBoard();
    }

    private void updatePointsText() {//this method will take the texure references and update them
        textViewPlayer1.setText("Player 1:" + player1Points);
        textViewPlayer2.setText("Player 2:" + player2Points);
    }

    private void resetBoard() {//this will reset all buttons to empty string, reset round count to 0 and make player 1 turn true
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setText("");
            }
        }

        roundCount = 0;
        player1Turn = true;
    }
    private void resetGame() {
        player1Points = 0;
        player2Points = 0;
        updatePointsText();
        resetBoard();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {//this method is to save the points of the players and on the board when the screen gets rotated
        super.onSaveInstanceState(outState);

        outState.putInt("roundCount", roundCount);//this variable will be saved under this key
        outState.putInt("player1Points", player1Points);
        outState.putInt("player2Points", player2Points);
        outState.putBoolean("player1Turn", player1Turn);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {//this method is to restore the saved points from the previous method
        super.onRestoreInstanceState(savedInstanceState);

        roundCount = savedInstanceState.getInt("roundCount");
        player1Points = savedInstanceState.getInt("player1Points");
        player2Points = savedInstanceState.getInt("player2Points");
        player1Turn = savedInstanceState.getBoolean("player1Turn");
    }
}